@extends('layouts.main')

@section('head')
@endsection

@section('title')
    Admin
@endsection

@section('nav')
  @include('components.navs.admin-nav')
@endsection

@section('content')
@endsection

@section('scripts')
@endsection

