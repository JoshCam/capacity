@extends('layouts.main')

@section('title')
    Admin
@endsection

@section('nav')
  @include('components.navs.admin-nav')
@endsection

@section('content')
    <h1>Admin Content</h1>
@endsection